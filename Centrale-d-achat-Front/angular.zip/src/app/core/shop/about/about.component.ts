import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['../../../assets/css/style.css','../../../assets/css/bootstrap.css',
              '../../../assets/css/font-awesome.min.css','../../../assets/css/responsive.css']
})
export class AboutComponent {

}
