import { Component } from '@angular/core';

@Component({
  selector: 'app-facture-avoir',
  templateUrl: './facture-avoir.component.html',
  styleUrls: ['./facture-avoir.component.css']
})
export class FactureAvoirComponent {

}
